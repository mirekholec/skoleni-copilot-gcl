using DotnetRandom.Demos;

namespace DotnetRandom.Tests;

/// <summary>
/// Testy pro ComplexIfDemo – ukázka složité logiky a starého C# stylu
/// </summary>
public class ComplexIfDemoTests
{
    private readonly ComplexIfDemo _demo = new ComplexIfDemo();

    [Fact]
    public void CalculateShipping_SmallPackage_ShortDistance_ReturnsBasePrice()
    {
        var result = _demo.CalculateShipping("neznamyzakaznik", 0.5, 50);

        Assert.Equal(79.0, result.Item1);
    }

    [Fact]
    public void CalculateShipping_MediumPackage_LongDistance_ReturnsCorrectPrice()
    {
        var result = _demo.CalculateShipping("neznamyzakaznik", 3.0, 600);

        Assert.Equal(349.0, result.Item1);
    }

    [Fact]
    public void CalculateShipping_PremiumCustomer_GetsDiscount()
    {
        var result = _demo.CalculateShipping("jan.novak", 0.5, 50);

        // 79.0 * 0.8 = 63.2
        // Záměrně nesprávná očekávaná hodnota pro ukázku "Debug with Copilot"
        Assert.Equal(63.0, result.Item1);
    }

    [Fact]
    public void CalculateShipping_PremiumCustomer_DescriptionContainsPremium()
    {
        var result = _demo.CalculateShipping("petra.svoboda", 1.0, 100);

        Assert.Contains("Premium", result.Item2);
    }

    [Fact]
    public void CalculateShipping_LargePackage_MediumDistance_ReturnsCorrectPrice()
    {
        var result = _demo.CalculateShipping("neznamyzakaznik", 20.0, 300);

        Assert.Equal(449.0, result.Item1);
    }

    [Fact]
    public void CalculateShipping_ZeroWeight_ThrowsArgumentException()
    {
        Assert.Throws<ArgumentException>(() => _demo.CalculateShipping("test", 0, 100));
    }

    [Fact]
    public void CalculateShipping_OverMaxWeight_ThrowsArgumentException()
    {
        Assert.Throws<ArgumentException>(() => _demo.CalculateShipping("test", 31.0, 100));
    }
}
