using DotnetRandom.Demos;

namespace DotnetRandom.Tests;

/// <summary>
/// Testy pro ExceptionDemo – ukázka dělení a výjimek
/// </summary>
public class ExceptionDemoTests
{
    private readonly ExceptionDemo _demo = new ExceptionDemo();

    [Fact]
    public void Divide_ValidNumbers_ReturnsCorrectResult()
    {
        int result = _demo.Divide(10, 2);

        Assert.Equal(5, result);
    }

    [Fact]
    public void Divide_NegativeDividend_ReturnsNegativeResult()
    {
        int result = _demo.Divide(-12, 3);

        Assert.Equal(-4, result);
    }

    [Fact]
    public void Divide_ByZero_ThrowsDivideByZeroException()
    {
        // DivideByZeroException je záměrně vyhazována bez kontroly
        Assert.Throws<DivideByZeroException>(() => _demo.Divide(5, 0));
    }

    [Fact]
    public void Divide_LargeNumbers_ReturnsCorrectResult()
    {
        int result = _demo.Divide(1000, 25);

        Assert.Equal(40, result);
    }
}
