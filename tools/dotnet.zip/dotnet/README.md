# DotnetRandom – Ukázky pro GitHub Copilot

Konzolová aplikace v **.NET 10** demonstrující vybrané funkce GitHub Copilot na záměrně zastaralém C# kódu.

## Struktura projektu

```
DotnetRandom/           – konzolová aplikace
  Demos/
    ExceptionDemo.cs    – demo výjimek (dělení nulou)
    ComplexIfDemo.cs    – demo složité podmínkové logiky
  IDemo.cs              – rozhraní pro demo scénáře
  Program.cs            – vstupní bod, výběr dema
DotnetRandom.Tests/     – unit testy (xUnit)
```

## Dema

- `exception` – Výjimky (Analyze with Copilot)
- `complex-if` – Složitý IF (Modernize)

## Spuštění

```bash
dotnet run --project DotnetRandom
```

Po spuštění zadejte název dema: `exception` nebo `complex-if`.

## Testy

```bash
dotnet test
```

Testy záměrně obsahují jeden neúspěšný případ (`CalculateShipping_PremiumCustomer_GetsDiscount`) – vhodné pro ukázku **Debug with Copilot**.
