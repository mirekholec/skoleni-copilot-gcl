namespace DotnetRandom;

/// <summary>
/// Rozhraní pro ukázkové demo scénáře
/// </summary>
public interface IDemo
{
    string Name { get; }
    string Description { get; }
    void Run();
}
