namespace DotnetRandom.Demos;

public class ComplexIfDemo : IDemo
{
    public string Name => "complex-if";
    public string Description => "Složitý IF – Modernize with Copilot";

    private readonly List<string> _premiumCustomers;

    public ComplexIfDemo()
    {
        _premiumCustomers = new List<string>() { "jan.novak", "petra.svoboda", "tomas.kral" };
    }

    public void Run()
    {
        Console.WriteLine("=== Demo: Složitý IF (Modernize) ===");
        Console.WriteLine("Kalkulátor ceny dopravy");

        Console.Write("Uživatelské jméno zákazníka: ");
        string username = Console.ReadLine() ?? string.Empty;

        Console.Write("Hmotnost zásilky v kg (např. 2.5): ");
        double weight = Double.Parse(Console.ReadLine() ?? "0");

        Console.Write("Vzdálenost v km: ");
        int distance = Int32.Parse(Console.ReadLine() ?? "0");

        Tuple<double, string> result = CalculateShipping(username, weight, distance);

        Console.WriteLine(String.Format("Cena dopravy: {0} Kč", result.Item1));
        Console.WriteLine(String.Format("Popis: {0}", result.Item2));
    }

    public Tuple<double, string> CalculateShipping(string username, double weight, int distance)
    {
        if (weight <= 0)
        {
            throw new ArgumentException("Hmotnost musí být kladná");
        }

        if (weight > 30.0)
        {
            throw new ArgumentException("Hmotnost přesahuje maximální limit 30 kg");
        }

        bool isPremium = false;
        for (int i = 0; i < _premiumCustomers.Count; i++)
        {
            if (_premiumCustomers[i] == username)
            {
                isPremium = true;
                break;
            }
        }

        double basePrice;
        string description;

        if (weight <= 1.0)
        {
            if (distance <= 100)
            {
                basePrice = 79.0;
                description = "Malý balík, krátká vzdálenost";
            }
            else if (distance <= 500)
            {
                basePrice = 129.0;
                description = "Malý balík, střední vzdálenost";
            }
            else
            {
                basePrice = 199.0;
                description = "Malý balík, velká vzdálenost";
            }
        }
        else if (weight <= 5.0)
        {
            if (distance <= 100)
            {
                basePrice = 149.0;
                description = "Střední balík, krátká vzdálenost";
            }
            else if (distance <= 500)
            {
                basePrice = 229.0;
                description = "Střední balík, střední vzdálenost";
            }
            else
            {
                basePrice = 349.0;
                description = "Střední balík, velká vzdálenost";
            }
        }
        else
        {
            if (distance <= 100)
            {
                basePrice = 299.0;
                description = "Velký balík, krátká vzdálenost";
            }
            else if (distance <= 500)
            {
                basePrice = 449.0;
                description = "Velký balík, střední vzdálenost";
            }
            else
            {
                basePrice = 699.0;
                description = "Velký balík, velká vzdálenost";
            }
        }

        if (isPremium != false)
        {
            basePrice = basePrice * 0.8;
            description = description + " (Premium sleva 20 %)";
        }

        return new Tuple<double, string>(basePrice, description);
    }
}
