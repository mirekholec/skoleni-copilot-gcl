namespace DotnetRandom.Demos;

public class ProfilerDemo : IDemo
{
    public string Name => "profiler";
    public string Description => "Memory leak + CPU hotspot – GitHub Copilot Profiler";

    private static readonly Dictionary<string, string> _reportCache = new();

    private static readonly List<byte[]> _allocations = new();

    public void Run()
    {
        Console.WriteLine("=== Demo: Profiler (GitHub Copilot Profiler) ===");
        Console.WriteLine("Simulace zpracování zákaznických reportů.");
        Console.WriteLine();
        Console.Write("Počet zákazníků ke zpracování (doporučeno 10 000+): ");

        if (!int.TryParse(Console.ReadLine(), out int count) || count <= 0)
            count = 10_000;

        Console.WriteLine();
        Console.WriteLine($"Průchod 1: zpracovávám {count} záznamů...");
        ProcessBatch("CUST", count);
        PrintStats();

        Console.WriteLine();
        Console.WriteLine("Stiskněte Enter pro spuštění druhého průchodu.");
        Console.WriteLine("Sledujte růst paměti v profileru – cache se nikdy nemaže.");
        Console.ReadLine();

        Console.WriteLine($"Průchod 2: zpracovávám dalších {count} záznamů...");
        ProcessBatch("CUST-B", count);
        PrintStats();
    }

    private void ProcessBatch(string prefix, int count)
    {
        for (int i = 0; i < count; i++)
        {
            string customerId = $"{prefix}-{i:D6}";

            string report = BuildReport(customerId);

            _reportCache[customerId] = report;
            _allocations.Add(new byte[512]);
        }
    }

    private string BuildReport(string customerId)
    {
        string[] fields =
        {
            "Jméno", "Příjmení", "Adresa", "Město", "PSČ",
            "Email", "Telefon", "Datum registrace", "Segment", "Skóre"
        };

        string report = $"[{customerId}] ";
        for (int i = 0; i < fields.Length; i++)
        {
            report += $"{fields[i]}={customerId}_{i}; ";
        }

        return report;
    }

    private void PrintStats()
    {
        long cacheBytes = _allocations.Count * 512L;
        Console.WriteLine($"  Cache: {_reportCache.Count} záznamů");
        Console.WriteLine($"  Alokace bufferů: {cacheBytes / 1024} KB ({cacheBytes / 1024 / 1024} MB)");
    }
}
