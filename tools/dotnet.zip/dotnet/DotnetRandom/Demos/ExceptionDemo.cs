namespace DotnetRandom.Demos;

public class ExceptionDemo : IDemo
{
    public string Name => "exception";
    public string Description => "Výjimky – Analyze with Copilot";

    public void Run()
    {
        Console.WriteLine("=== Demo: Výjimky (Analyze with Copilot) ===");
        Console.WriteLine("Celočíselná kalkulačka. Zadejte první číslo:");
        string input1 = Console.ReadLine();

        Console.WriteLine(String.Format("Zadejte druhé číslo (0 způsobí výjimku {0}):", nameof(DivideByZeroException)));
        string input2 = Console.ReadLine();

        int a = ParseNumber(input1);
        int b = ParseNumber(input2);

        int result = Divide(a, b);
        Console.WriteLine(String.Format("Výsledek: {0} / {1} = {2}", a, b, result));
    }

    private int ParseNumber(string value)
    {
        if (value == null)
        {
            throw new ArgumentNullException("value", "Hodnota nesmí být null");
        }

        if (!Int32.TryParse(value, out int result))
        {
            throw new FormatException("Neplatné číslo: " + value);
        }

        return result;
    }

    public int Divide(int a, int b)
    {
        return a / b;
    }
}
