using DotnetRandom;
using DotnetRandom.Demos;
using Spectre.Console;

AnsiConsole.Write(new FigletText("GitHub Copilot").Color(Color.DodgerBlue1));
AnsiConsole.MarkupLine("[grey]Ukázky funkcí GitHub Copilot pro .NET[/]");
AnsiConsole.WriteLine();

List<IDemo> demos =
[
    new ExceptionDemo(),
    new ComplexIfDemo(),
    new ProfilerDemo(),
];

IDemo selected = AnsiConsole.Prompt(
    new SelectionPrompt<IDemo>()
        .Title("Vyberte [dodgerblue1]demo[/] pomocí šipek a potvrďte [green]Enter[/]:")
        .UseConverter(d => $"[bold]{d.Name}[/] [grey]–[/] {d.Description}")
        .AddChoices(demos));

AnsiConsole.WriteLine();
selected.Run();

